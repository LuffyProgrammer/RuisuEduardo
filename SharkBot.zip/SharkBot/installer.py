import os

os.system('pip install aiogram==2.16')
os.system('pip install aioify==0.4.0')
os.system('pip install deezloader==2021.11.9')
os.system('pip install requests==2.26.0')
os.system('pip install mutagen==1.45.1')
os.system('pip install Pillow==8.4.0')
os.system('pip install youtube_dl==2021.6.6')